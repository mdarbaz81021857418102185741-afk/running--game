# Running Game

A simple Kivy endless-running game for Android.

## Controls
- Tap anywhere to jump.
- Avoid the green obstacles.
- Score increases while you run.
- Tap after Game Over to restart.

## Build APK
The repository includes a GitHub Actions workflow. After pushing the files to GitHub:
1. Open the repository.
2. Open **Actions**.
3. Select **Build Running Game APK**.
4. Run the workflow with **Run workflow**.
5. When it finishes, open the workflow run and download the `running-game-apk` artifact.
